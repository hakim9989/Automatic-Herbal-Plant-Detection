import 'package:flutter/material.dart';
import 'package:herbal_app/widgets/projectoverview.dart';
import 'package:provider/provider.dart';
import '../state/auth_state.dart';
import '../state/theme_state.dart';
//import 'project_overview_screen.dart'; // import the new screen

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authState = Provider.of<AuthState>(context, listen: false);
    final themeState = Provider.of<ThemeState>(context);

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Settings"),
        backgroundColor: Colors.green,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text("Dark Mode"),
            value: themeState.isDarkMode,
            onChanged: (value) => themeState.toggleTheme(value),
            secondary: const Icon(Icons.dark_mode),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text("About the Project"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ProjectOverviewScreen()),
              );
            },
          ),
          // ... other list tiles ...
          ListTile(
            leading: const Icon(Icons.group),
            title: const Text("Project Members"),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('UEB3202521 - Ibrahim Abdul Hakim'),
                Text('UEB3237423 - Ghartey Adriana'),
                Text('UEB3208821 - Appiah Jasmine Boatemaa'),
                Text('UEB3219521 - Asante Esther Kyeremaah'),
                Text('UEB3220721 - Dapaa Nana Yaw Atobrah'),
              ],
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text("Log Out", style: TextStyle(color: Colors.red)),
            onTap: () => authState.logout(),
          ),
        ],
      ),
    );
  }
}
