import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../services/detection_service.dart';
import '../state/auth_state.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  Uint8List? _imageBytes;
  String? _fileName;
  Map<String, dynamic>? _result;

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      setState(() {
        _imageBytes = bytes;
        _fileName = pickedFile.name;
        _result = null;
      });
    }
  }

  Future<void> _detectPlant() async {
    if (_imageBytes == null || _fileName == null) return;
    final authState = Provider.of<AuthState>(context, listen: false);
    final result = await DetectionService().detectPlant(
      imageBytes: _imageBytes!,
      fileName: _fileName!,
      authToken: authState.authToken!,
    );
    setState(() {
      _result = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Background image with overlay
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/plant.jpeg', 
            fit: BoxFit.cover,
          ),
          Container(
            color: Colors.black.withOpacity(0.3), // subtle dark overlay
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Scan a Plant Leaf',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      shadows: [
                        Shadow(
                          color: Colors.black54,
                          offset: Offset(2, 2),
                          blurRadius: 4,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Cute image preview card
                  Container(
                    width: 300,
                    height: 300,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.green.withOpacity(0.3),
                          blurRadius: 20,
                          offset: Offset(0, 10),
                        ),
                      ],
                      border: Border.all(color: Colors.green.shade200, width: 2),
                    ),
                    clipBehavior: Clip.hardEdge,
                    child: _imageBytes != null
                        ? Image.memory(
                            _imageBytes!,
                            fit: BoxFit.cover,
                          )
                        : Center(
                            child: Text(
                              'No image selected',
                              style: TextStyle(
                                color: Colors.green.shade400,
                                fontWeight: FontWeight.w600,
                                fontSize: 18,
                              ),
                            ),
                          ),
                  ),
                  const SizedBox(height: 24),

                  // Cute Pick Image Button
                  SizedBox(
                    width: 200,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(32),
                        ),
                        backgroundColor: Colors.green.shade400,
                        shadowColor: Colors.green.shade700,
                        elevation: 8,
                      ),
                      onPressed: _pickImage,
                      icon: const Icon(Icons.photo_library, size: 28),
                      label: const Text(
                        'Pick Image',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  // Cute Detect Plant Button
                  SizedBox(
                    width: 200,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(32),
                        ),
                        backgroundColor:
                            _imageBytes != null ? Colors.green.shade700 : Colors.grey.shade400,
                        shadowColor: _imageBytes != null ? Colors.green.shade900 : Colors.grey.shade600,
                        elevation: 8,
                      ),
                      onPressed: _imageBytes != null ? _detectPlant : null,
                      icon: const Icon(Icons.search, size: 28),
                      label: const Text(
                        'Detect Plant',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Result card with cute style
                  if (_result != null)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.95),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.green.withOpacity(0.3),
                            blurRadius: 20,
                            offset: Offset(0, 10),
                          ),
                        ],
                        border: Border.all(color: Colors.green.shade200, width: 2),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildResultText('Plant Type', _result!['plant_type']),
                          const SizedBox(height: 12),
                          _buildResultText('Confidence', '${_result!['confidence']}%'),
                          const SizedBox(height: 12),
                          _buildResultText('Description', _result!['details']?['description']),
                          const SizedBox(height: 12),
                          _buildResultText('Medicinal Uses', _result!['details']?['medicinal_uses']),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultText(String title, String? content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$title:',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: Colors.green,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          content ?? 'No information available.',
          style: const TextStyle(fontSize: 16),
        ),
      ],
    );
  }
}
