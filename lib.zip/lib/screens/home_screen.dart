import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/history_service.dart';
import '../state/auth_state.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<Map<String, dynamic>> _summaryFuture;

  @override
  void initState() {
    super.initState();
    _summaryFuture = _fetchDetectionSummary();
  }

  Future<Map<String, dynamic>> _fetchDetectionSummary() async {
    final historyService = HistoryService();
    final history = await historyService.getHistory();

    Map<String, int> plantCount = {};
    for (var entry in history) {
      final plant = entry['plant_type'] ?? 'Unknown';
      plantCount[plant] = (plantCount[plant] ?? 0) + 1;
    }

    return {
      'total': history.length,
      'plantCount': plantCount,
    };
  }

  @override
  Widget build(BuildContext context) {
    final authState = Provider.of<AuthState>(context, listen: false);

    if (!authState.isLoggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('Dashboard'), backgroundColor: Colors.green),
        body: const Center(child: Text('Please login to view your dashboard')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Dashboard'),
        backgroundColor: Colors.green,
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _summaryFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError || !snapshot.hasData) {
            return const Center(child: Text('Failed to load summary'));
          }

          final total = snapshot.data!['total'] as int;
          final plantCount = snapshot.data!['plantCount'] as Map<String, int>;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Total Detections: $total",
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                const Text("Plant Count by Type:",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                ...plantCount.entries.map((e) => ListTile(
                      leading: const Icon(Icons.local_florist, color: Colors.green),
                      title: Text(e.key),
                      trailing: Text('${e.value} detections'),
                    )),
              ],
            ),
          );
        },
      ),
    );
  }
}
