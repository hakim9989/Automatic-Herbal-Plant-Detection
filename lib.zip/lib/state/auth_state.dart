import 'package:flutter/material.dart';

class AuthState with ChangeNotifier {
  String? _userId;
  String? _userName;
  String? _authToken;

  // Getters
  bool get isLoggedIn => _authToken != null && _authToken!.isNotEmpty;
  String? get userId => _userId;
  String? get userName => _userName;
  String? get authToken => _authToken; // ✅ Fixed getter

  // Login method
  void login(String userId, String userName, String token) {
    _userId = userId;
    _userName = userName;
    _authToken = token;
    notifyListeners();
  }

  // Logout method
  void logout() {
    _userId = null;
    _userName = null;
    _authToken = null;
    notifyListeners();
  }
}
