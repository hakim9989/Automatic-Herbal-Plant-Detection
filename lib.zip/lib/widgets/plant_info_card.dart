import 'package:flutter/material.dart';

class PlantInfoCard extends StatelessWidget {
  final String plantName;
  final String scientificName;
  final String description;
  final String medicinalUses;
  final double confidence;

  const PlantInfoCard({
    super.key,
    required this.plantName,
    required this.scientificName,
    required this.description,
    required this.medicinalUses,
    required this.confidence,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(12),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(
              plantName,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Text("Scientific Name: $scientificName"),
            Text("Confidence: ${(confidence * 100).toStringAsFixed(2)}%"),
            const SizedBox(height: 10),
            Text("Description:", style: TextStyle(fontWeight: FontWeight.bold)),
            Text(description),
            const SizedBox(height: 10),
            Text("Medicinal Uses:", style: TextStyle(fontWeight: FontWeight.bold)),
            Text(medicinalUses),
          ],
        ),
      ),
    );
  }
}
