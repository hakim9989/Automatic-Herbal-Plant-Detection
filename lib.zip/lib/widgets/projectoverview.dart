import 'package:flutter/material.dart';

class ProjectOverviewScreen extends StatelessWidget {
  const ProjectOverviewScreen({super.key});

  final String projectOverview = '''
 Project Overview: Automatic Herbal Plant Detection

Project Title: 
Automatic Herbal Plant Detection  

Institution:  
University of Energy and Natural Resources (UENR), School of Sciences, Department of Information Technology and Decision Sciences  

Team Members:  
- UEB3202521 - Ibrahim Abdul Hakim  
- UEB3237423 - Ghartey Adriana  
- UEB3208821 - Appiah Jasmine Boatemaa  
- UEB3219521 - Asante Esther Kyeremaah  
- UEB3220721 - Dapaa Nana Yaw Atobrah  

Supervisor:  
Mr. Jacob Mensah  

---

 Objective  
The project aims to develop a **mobile application** that leverages **Convolutional Neural Networks (CNNs), Artificial Neural Networks (ANN), and NASNet** to accurately identify medicinal herbs from plant images in real-time. The system addresses the limitations of traditional herb identification methods, which are time-consuming, expertise-dependent, and prone to human error.  

Key Goals: 
1. Train deep learning models (CNN, ANN, NASNet) for herb classification.  
2. Develop a user-friendly mobile app for image capture and result display.  
3. Provide medicinal properties, dosage recommendations, and safety information.  
4. Achieve high accuracy (currently **81%**) and fast processing (**7–10 seconds per image**).  

---

Problem Statement  
Traditional herb identification relies on manual examination by experts, which is:  
- Slow and labor-intensive.  
- Inaccessible to non-experts.  
- Error-prone due to morphological similarities between species.  
- Threatened by environmental degradation and lack of preservation.  

The project addresses these challenges with an **automated, AI-driven solution**.  

---

 Methodology  
1. Data Collection & Preprocessing:  
   - Curate a dataset of 6 medicinal plants (Betel, Lemon, Tulsi, Mint, Neem, Guava) from Kaggle (500 images per species).  
   - Resize images to 224×224 pixels and augment data (rotation, flipping) to enhance model robustness.  

2. Model Development:
   - Implement CNN architectures (ResNet50, DenseNet201, VGG16, InceptionV3) and compare performance.  
   - Optimize for mobile deployment using NASNet for efficiency.  

3. Mobile App Integration:  
   - Features:  
     - Image upload.  
     - Real-time herb identification.  
     - Display of medicinal properties and uses.  
   - Platforms: Android and iOS.  

4. Evaluation:
   - Metrics: Accuracy (94%), precision, recall.  
   - Testing: Usability studies and field validation.  

---

Significance  
- Healthcare: Supports evidence-based herbal medicine for practitioners and researchers.  
- Accessibility: Democratizes herb identification for rural communities and enthusiasts.  
- Preservation: Digitizes traditional knowledge to combat biodiversity loss.  
- Innovation: Combines AI (CNNs/ANN) with mobile technology for scalable solutions.  

---

 Challenges & Future Work  
1. Data Scarcity: Expand datasets to include more species and environments.  
2. Complex Backgrounds: Improve segmentation algorithms for real-world images.  
3. Inter-Species Similarity: Explore hybrid models (e.g., CNNs + Capsule Networks).  
4. Global Scalability: Add multilingual support and regional herb databases.  

---

 Conclusion  
This project bridges **traditional herbal medicine** and **modern AI** by delivering a practical, high-accuracy mobile tool. It empowers users to identify medicinal plants safely and efficiently, promoting **sustainable healthcare** and **biodiversity conservation**. Future enhancements will focus on expanding plant coverage and improving model robustness.  

Technologies Used:  
- Flutter (Mobile App)  
- Python (Deep Learning: TensorFlow/Keras)  
- Xampp (Backend)  
- REST APIs (PHP)  

Deliverables: 
- Functional mobile app.  
- Trained CNN/ANN models.  
- Annotated herb dataset.  
- Comprehensive documentation.  
''';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Project Overview'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: SelectableText(
          projectOverview,
          style: const TextStyle(fontSize: 16, height: 1.6),
        ),
      ),
    );
  }
}
