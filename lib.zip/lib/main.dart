import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/auth_screen.dart';
import 'screens/main_navigation.dart';
import 'services/auth_service.dart';
import 'state/auth_state.dart';
import 'state/theme_state.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthState()),
        ChangeNotifierProvider(create: (_) => ThemeState()),
        Provider(create: (_) => AuthService()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<AuthState, ThemeState>(
      builder: (context, authState, themeState, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Herbal Plant App',
          theme: themeState.isDarkMode
              ? ThemeData.dark().copyWith(
                  primaryColor: Colors.green,
                  colorScheme: ThemeData.dark().colorScheme.copyWith(
                        secondary: Colors.greenAccent,
                      ),
                )
              : ThemeData.light().copyWith(
                  primaryColor: Colors.green,
                  colorScheme: ThemeData.light().colorScheme.copyWith(
                        secondary: Colors.greenAccent,
                      ),
                ),
          home: authState.isLoggedIn
              ? const MainNavigation()
              : const AuthScreen(),
        );
      },
    );
  }
}
