import 'php_api_service.dart';
import '../state/auth_state.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  final PhpApiService _phpApiService = PhpApiService();

  bool isValidUserName(String userName) {
    final regex = RegExp(r'^[a-zA-Z0-9]{5,20}$');
    return regex.hasMatch(userName);
  }

  bool isValidPassword(String password) {
    return password.length >= 6;
  }

  Future<void> registerWithUserName(String userName, String password) async {
    if (!isValidUserName(userName)) {
      throw Exception('Username must be 5–20 characters long and contain only letters and numbers.');
    }
    if (!isValidPassword(password)) {
      throw Exception('Password must be at least 6 characters.');
    }

    // Exclude auth token for registration
    final response = await _phpApiService.post(
      'register.php',
      {
        'userName': userName,
        'password': password,
      },
      includeAuthToken: false,
    );

    if (!response['success']) {
      throw Exception(response['message']);
    }
  }

  Future<void> signInWithUserName(String userName, String password, AuthState authState) async {
    if (!isValidUserName(userName)) {
      throw Exception('Invalid username. Must be 5–20 letters or numbers.');
    }
    if (!isValidPassword(password)) {
      throw Exception('Invalid password. Must be at least 6 characters.');
    }

    // Exclude auth token for login
    final response = await _phpApiService.post(
      'login.php',
      {
        'userName': userName,
        'password': password,
      },
      includeAuthToken: false,
    );

    if (response['success']) {
      final authToken = response['auth_token'];
      if (authToken == null) {
        throw Exception('No authentication token received.');
      }

      // Save token to SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('auth_token', authToken);

      authState.login(
        response['user_id'].toString(),
        response['user_name'],
        authToken,
      );
    } else {
      throw Exception(response['message']);
    }
  }

  Future<void> signOut(AuthState authState) async {
    try {
      await _phpApiService.get('logout.php');
    } catch (_) {
      // Ignore server errors during logout.
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    authState.logout();
  }
}
