import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class DetectionService {
  final String baseUrl = 'http://172.20.10.7/plant_app/api';

  Future<Map<String, dynamic>> detectPlant({
    required Uint8List imageBytes,
    required String fileName,
    required String authToken,
  }) async {
    final url = Uri.parse('$baseUrl/detect_plant.php');
    final request = http.MultipartRequest('POST', url);
    request.headers['X-Auth-Token'] = authToken;
    request.files.add(http.MultipartFile.fromBytes('image', imageBytes, filename: fileName));

    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Plant detection failed');
    }
  }
}
