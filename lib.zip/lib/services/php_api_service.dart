import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class PhpApiService {
  final String _baseUrl = "http://172.20.10.7/plant_app/api/";

  Future<String?> _getStoredToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<Map<String, String>> _getAuthHeaders({
    bool includeContentType = true,
    bool includeAuthToken = true,
  }) async {
    final headers = <String, String>{};
    if (includeAuthToken) {
      final token = await _getStoredToken();
      if (token != null && token.isNotEmpty) {
        headers['X-Auth-Token'] = token;
      }
    }
    if (includeContentType) {
      headers['Content-Type'] = 'application/json';
    }
    return headers;
  }

  Future<Map<String, dynamic>> post(
    String endpoint,
    Map<String, dynamic> data, {
    bool includeAuthToken = true,
  }) async {
    final headers = await _getAuthHeaders(
      includeContentType: true,
      includeAuthToken: includeAuthToken,
    );

    final response = await http.post(
      Uri.parse('$_baseUrl$endpoint'),
      headers: headers,
      body: json.encode(data),
    );

    final body = json.decode(response.body);
    if (response.statusCode == 200 && body['success'] == true) {
      return body;
    } else {
      throw Exception(body['message'] ?? 'POST request failed');
    }
  }

  Future<Map<String, dynamic>> get(String endpoint) async {
    final headers = await _getAuthHeaders(includeContentType: false);
    final response = await http.get(
      Uri.parse('$_baseUrl$endpoint'),
      headers: headers,
    );

    final body = json.decode(response.body);
    if (response.statusCode == 200 && body['success'] == true) {
      return body;
    } else {
      throw Exception(body['message'] ?? 'GET request failed');
    }
  }

  Future<void> clearStoredToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
  }

  Future<Map<String, String>> getAuthHeaders() => _getAuthHeaders();
}
