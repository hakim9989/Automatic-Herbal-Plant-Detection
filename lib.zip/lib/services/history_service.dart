import 'php_api_service.dart';

class HistoryService {
  final PhpApiService _api = PhpApiService();

  // Fetch user detection history
  Future<List<Map<String, dynamic>>> getHistory() async {
    final res = await _api.get('get_history.php');
    return List<Map<String, dynamic>>.from(res['detections']);
  }

  // Delete a detection by id
  Future<void> deleteDetection(int id) async {
    await _api.post('delete_detection.php', {'id': id});
  }
}
